// Brand config
const BRAND_NAME = "Azir Complexx";

// Fake product data
const PRODUCTS = [
  {id:1,title:"Logo Hoodie",price:78,category:"tops",collection:"street",img:"assets/p1.jpg",sizes:["S","M","L","XL"]},
  {id:2,title:"Boxy Tee",price:34,category:"tops",collection:"studio",img:"assets/p2.jpg",sizes:["S","M","L"]},
  {id:3,title:"Technical Cargo Pant",price:92,category:"bottoms",collection:"street",img:"assets/p3.jpg",sizes:["28","30","32","34","36"]},
  {id:4,title:"Cropped Puffer",price:129,category:"outerwear",collection:"noir",img:"assets/p4.jpg",sizes:["S","M","L"]},
  {id:5,title:"Minimal Cap",price:28,category:"accessories",collection:"street",img:"assets/p5.jpg",sizes:["OS"]},
  {id:6,title:"Studio Tight Longsleeve",price:49,category:"tops",collection:"studio",img:"assets/p6.jpg",sizes:["S","M","L"]},
  {id:7,title:"Satin Slip Skirt",price:69,category:"bottoms",collection:"noir",img:"assets/p7.jpg",sizes:["XS","S","M","L"]},
  {id:8,title:"Oversized Denim Jacket",price:118,category:"outerwear",collection:"street",img:"assets/p8.jpg",sizes:["S","M","L","XL"]},
];

const state = {
  query: "",
  filter: "all",
  sort: "featured",
  collection: null,
  cart: JSON.parse(localStorage.getItem("cart")||"[]")
};

const $ = s => document.querySelector(s);
const $$ = s => document.querySelectorAll(s);

function money(n){ return `$${n.toFixed(2)}` }

function renderProducts(){
  const grid = $("#products");
  let items = PRODUCTS.filter(p => 
    (state.filter==="all"||p.category===state.filter) &&
    (!state.collection || p.collection===state.collection) &&
    (state.query === "" || p.title.toLowerCase().includes(state.query))
  );
  if(state.sort==="priceLow") items.sort((a,b)=>a.price-b.price);
  if(state.sort==="priceHigh") items.sort((a,b)=>b.price-a.price);

  grid.innerHTML = items.map(p => `
    <div class="card">
      <div class="card-img" style="background-image:url('${p.img}')"></div>
      <div class="card-body">
        <div class="card-title">${p.title}</div>
        <div class="price"><span>${p.category}</span><strong>${money(p.price)}</strong></div>
        <label class="variant">
          <span>Size</span>
          <select id="size-${p.id}">
            ${p.sizes.map(s=>`<option>${s}</option>`).join("")}
          </select>
        </label>
        <button class="btn" onclick="addToCart(${p.id})">Add to cart</button>
      </div>
    </div>
  `).join("");
}

function addToCart(id){
  const p = PRODUCTS.find(x=>x.id===id);
  const size = $(`#size-${id}`).value;
  const itemKey = `${id}-${size}`;
  const existing = state.cart.find(x=>x.key===itemKey);
  if(existing){ existing.qty += 1; }
  else { state.cart.push({key:itemKey,id, size, qty:1}); }
  persistCart();
  openCart();
  renderCart();
}

function persistCart(){
  localStorage.setItem("cart", JSON.stringify(state.cart));
  $("#cartCount").textContent = state.cart.reduce((a,c)=>a+c.qty,0);
}

function renderCart(){
  const wrap = $("#cartItems");
  if(state.cart.length===0){
    wrap.innerHTML = `<p style="color:#a1a1aa">Your cart is empty.</p>`;
    $("#subtotal").textContent = money(0);
    return;
  }
  wrap.innerHTML = state.cart.map(it=>{
    const p = PRODUCTS.find(x=>x.id===it.id);
    return `
    <div class="cart-item">
      <div class="thumb" style="background-image:url('${p.img}')"></div>
      <div>
        <div><strong>${p.title}</strong></div>
        <div class="meta">${it.size} • ${money(p.price)}</div>
      </div>
      <div>
        <button class="icon-btn" onclick="changeQty('${it.key}',-1)">−</button>
        <span style="padding:0 8px">${it.qty}</span>
        <button class="icon-btn" onclick="changeQty('${it.key}',1)">+</button>
      </div>
    </div>`
  }).join("");

  const subtotal = state.cart.reduce((sum,it)=>{
    const p = PRODUCTS.find(x=>x.id===it.id);
    return sum + p.price * it.qty;
  },0);
  $("#subtotal").textContent = money(subtotal);
}

function changeQty(key,delta){
  const idx = state.cart.findIndex(x=>x.key===key);
  if(idx<0) return;
  state.cart[idx].qty += delta;
  if(state.cart[idx].qty<=0) state.cart.splice(idx,1);
  persistCart(); renderCart();
}

function openCart(){ $("#cartDrawer").classList.add("open") }
function closeCart(){ $("#cartDrawer").classList.remove("open") }

// Event bindings
window.addEventListener("DOMContentLoaded", ()=>{
  // brand text
  $$(".brand-name").forEach(el=>el.textContent = BRAND_NAME);
  $("#year").textContent = new Date().getFullYear();

  renderProducts();
  persistCart(); renderCart();

  $("#filterCategory").addEventListener("change", e=>{ state.filter = e.target.value; renderProducts() });
  $("#sortBy").addEventListener("change", e=>{ state.sort = e.target.value; renderProducts() });
  $("#search").addEventListener("input", e=>{ state.query = e.target.value.trim().toLowerCase(); renderProducts() });
  $$(".collection-card").forEach(el=>{
    el.addEventListener("click", ev=>{ 
      state.collection = el.dataset.collection; 
      document.getElementById("filterCategory").value = "all";
      state.filter = "all";
      renderProducts();
    });
  });
  document.getElementById("cartBtn").addEventListener("click", openCart);
  document.getElementById("closeCart").addEventListener("click", closeCart);
  document.getElementById("checkout").addEventListener("click", ()=>{
    alert("This demo site does not process payments. Connect to Shopify/Stripe or a backend to go live.");
  });
});

// Expose for inline handlers
window.addToCart = addToCart;
window.changeQty = changeQty;
window.openCart = openCart;
